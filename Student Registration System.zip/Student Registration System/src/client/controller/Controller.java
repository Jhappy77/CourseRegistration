package client.controller;

import client.view.MyGUI;

public class Controller {

	private MyGUI view;
	
	private ClientApp server;
	
	public Controller(MyGUI view) {
		this.view = view;
		ClientApp server = new ClientApp("localhost", 8080, this);
		System.out.println("Launched client app");
		server.communicate();
	}
	
	public void login(int id, String password) {
		server.attemptLogin(id, password);
	}
	
	public void loginAttempt(Boolean b) {
		if(b)
			System.out.println("Wrong password/ User doesn't exist!");
	}
	
}
